/*
    CH-231-A
    problem1.cpp
    Jan Steinmueller
    j.steinmueller@jacobs-university.de
*/
#include <iostream>
#include <chrono>
#include "RedBlackTree.h"

using namespace std;
using namespace chrono;

int main(int argc, char** argv){

	/*only got working rotate, insertFixup, insert function and constructor*/

	RedBlackTree tree;
	tree.insertRB(1);
	return 0;
}