#include "Node.h"

Node::Node(int nKey, int nValue){
	key = nKey;
	value = nValue;
}
