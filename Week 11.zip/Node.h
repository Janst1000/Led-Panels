#ifndef _NODE_H_
#define _NODE_H_

class Node{
	public:
		int key;
		int value;
		Node(int nKey, int nValue);
};

#endif